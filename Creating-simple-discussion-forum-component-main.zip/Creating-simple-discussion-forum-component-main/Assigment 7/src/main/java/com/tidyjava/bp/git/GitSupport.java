package com.tidyjava.bp.git;

import java.io.File;

public interface GitSupport {
    File getWorkTree();
}
