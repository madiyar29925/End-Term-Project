# Creating-simple-discussion-forum-component
Keep in mind that you will reuse this component for your next project, so keep it clear, cohesive and reusable
