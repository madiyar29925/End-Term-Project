package kz.reself.springdata.service;

import kz.reself.springdata.entity.Page;

import java.util.List;

public interface PageService {

    List<Page> getAll();
}
