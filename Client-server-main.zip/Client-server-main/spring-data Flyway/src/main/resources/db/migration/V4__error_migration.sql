INSERT into customer (name) VALUES
('success customer');