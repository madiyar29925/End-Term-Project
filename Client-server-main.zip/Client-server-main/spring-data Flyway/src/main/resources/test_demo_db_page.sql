INSERT INTO test_demo_db.page (num, book_id) VALUES (1, 1);
INSERT INTO test_demo_db.page (num, book_id) VALUES (2, 1);